import style from './SectionVite.module.css'

export function SectionVite(){

    return(
        <section className={style.sectionVite}>
            <h1>Um pouco sobre mim</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores at repellendus sed possimus quasi tempora rerum quis, delectus, quibusdam, ipsam aperiam similique eligendi iste. Fugiat labore reprehenderit nobis eligendi porro!</p>
        </section>
    )
}