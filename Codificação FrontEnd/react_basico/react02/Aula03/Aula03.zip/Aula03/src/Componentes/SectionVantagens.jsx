import style from './SectionVantagens.module.css'

export function SectionVantagens(){

    return(
        <section className={style.section2}>
            <h1>Experiência</h1>
            <ul>
                <li>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium quaerat qui sunt possimus cumque omnis, necessitatibus voluptatibus cum natus non quam delectus officiis deleniti veritatis in? Iste laborum nostrum veritatis maxime nisi! Soluta voluptatem officia aliquid alias possimus, neque architecto nulla eum rem autem 
                </li>
                <li>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium quaerat qui sunt possimus cumque omnis, necessitatibus voluptatibus cum natus non quam delectus officiis deleniti veritatis in? Iste laborum nostrum veritatis maxime nisi! Soluta voluptatem officia aliquid alias possimus, neque architecto nulla eum rem autem 
                </li>
                <li>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium quaerat qui sunt possimus cumque omnis, necessitatibus voluptatibus cum natus non quam delectus officiis deleniti veritatis in? Iste laborum nostrum veritatis maxime nisi! Soluta voluptatem officia aliquid alias possimus, neque architecto nulla eum rem autem 
                </li>
                <li>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium quaerat qui sunt possimus cumque omnis, necessitatibus voluptatibus cum natus non quam delectus officiis deleniti veritatis in? Iste laborum nostrum veritatis maxime nisi! Soluta voluptatem officia aliquid alias possimus, neque architecto nulla eum rem autem 
                </li>               
            </ul>
        </section>
    )
}